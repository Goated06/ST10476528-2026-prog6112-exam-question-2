package com.mattresssales;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class ProductCalculationsTest {
    // Q2.6 - Unit Test 1
    @Test
    void GetVat_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(525.00, calc.GetVat(), 0.001);
    }

    // Q2.6 - Unit Test 2
    @Test
    void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(4200.00, calc.GetTotal(), 0.001);
    }
}
