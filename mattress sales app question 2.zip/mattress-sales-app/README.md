# Mattress Sales App - Question 2

A simple Java Swing desktop app for recording mattress sales.

## Features

- Customer name text field, product dropdown, and price text field
- Products: Cozy Nights Monarch, Restonic Barbados, Sealy Phuket
- VAT = 15% of price; commission = 5% of price
- Total = price + VAT + commission
- Process button displays results and appends the sale to `data.txt`
- File > Exit; Tools > Process; Tools > Clear
- `IProductCalculations` interface and `ProductCalculations` implementation
- Two JUnit 5 tests from Question 2.6

## Requirements

Java JDK 17+ and, for running tests, Apache Maven.

## Run with Maven

```bash
mvn compile exec:java
```

## Run without Maven

From the project root:

```bash
javac -d out src/main/java/com/mattresssales/*.java
java -cp out com.mattresssales.ProductApp
```

On Windows Command Prompt, use the same commands.

## Run unit tests

```bash
mvn test
```

## Example

For customer Joe Bloggs, Cozy Nights Monarch, price R3500:

- VAT: R525.00
- Commission: R175.00
- Total: R4200.00

The `data.txt` file is created in the working directory from which the app is run. Each sale is appended rather than overwriting previous entries. `data.txt` is excluded from Git so customer information is not uploaded accidentally.

## Upload to GitHub

1. Create a new repository on GitHub (e.g. `mattress-sales-app`).
2. Upload all files and the `src` folder in this project (or use `git init`, `git add .`, `git commit`).
3. Open in NetBeans or IntelliJ as a Maven project, or run with the commands above.
