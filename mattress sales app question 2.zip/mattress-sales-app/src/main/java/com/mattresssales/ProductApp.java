package com.mattresssales;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Locale;

public class ProductApp extends JFrame {
    private final JTextField customerField = new JTextField(20);
    private final JComboBox<String> productBox = new JComboBox<>(new String[] {
        "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"
    });
    private final JTextField priceField = new JTextField(20);

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(510, 310);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> dispose());
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processSale());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        JPanel form = new JPanel(new GridLayout(4, 2, 12, 15));
        form.setBorder(BorderFactory.createEmptyBorder(24, 25, 24, 25));
        form.add(new JLabel("Customer Name:"));
        form.add(customerField);
        form.add(new JLabel("Select Product:"));
        form.add(productBox);
        form.add(new JLabel("Enter Price:"));
        form.add(priceField);
        form.add(new JLabel(""));
        JButton processButton = new JButton("PROCESS");
        processButton.addActionListener(e -> processSale());
        form.add(processButton);
        add(form, BorderLayout.CENTER);
    }

    private void processSale() {
        String customer = customerField.getText().trim();
        String product = (String) productBox.getSelectedItem();
        if (customer.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the customer's name.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            double price = Double.parseDouble(priceField.getText().trim());
            ProductCalculations calc = new ProductCalculations(price);
            String result = String.format(Locale.US,
                    "Customer Name: %s%nProduct: %s%nVAT: R %.2f%nCOMMISSION: R %.2f%nTOTAL: R %.2f",
                    customer, product, calc.GetVat(), calc.GetCommission(), calc.GetTotal());
            saveSale(result);
            JOptionPane.showMessageDialog(this, result, "Message", JOptionPane.INFORMATION_MESSAGE);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid positive price.",
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save data.txt: " + ex.getMessage(),
                    "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveSale(String result) throws IOException {
        Path path = Path.of("data.txt");
        boolean newFile = !Files.exists(path) || Files.size(path) == 0;
        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            if (newFile) {
                writer.write("DATA LOG");
                writer.newLine();
            }
            writer.write("**************************************");
            writer.newLine();
            writer.write(result);
            writer.newLine();
            writer.write("**************************************");
            writer.newLine();
        }
    }

    private void clearForm() {
        customerField.setText("");
        priceField.setText("");
        productBox.setSelectedIndex(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
