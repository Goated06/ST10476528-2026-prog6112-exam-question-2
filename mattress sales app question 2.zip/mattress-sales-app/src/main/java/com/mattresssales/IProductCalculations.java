package com.mattresssales;

public interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}
